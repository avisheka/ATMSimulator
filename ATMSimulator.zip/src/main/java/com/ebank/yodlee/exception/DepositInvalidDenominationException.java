package com.ebank.yodlee.exception;

/**
 * @author aarang
 *
 */
public class DepositInvalidDenominationException extends RuntimeException {

	public DepositInvalidDenominationException(String message) {
		super(message);
	}
}
