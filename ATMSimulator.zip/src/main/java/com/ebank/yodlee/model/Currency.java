package com.ebank.yodlee.model;

public class Currency {
	
	private int denomination;
	
	public Currency(int _denomination) {
		this.denomination = _denomination;
	}
	
	public int getDenomination() {
		return this.denomination;
	}
	
}
